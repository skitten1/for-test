-- Translate legacy Chinese labels already stored by the default system-function seed.
-- Only built-in system functions are changed; user-created features are left untouched.
UPDATE system_functions
SET category_name = CASE category_name
    WHEN '数据库管理' THEN 'Database Management'
    WHEN '集群信息' THEN 'Cluster Information'
    WHEN '事务管理' THEN 'Transaction Management'
    WHEN '任务管理' THEN 'Task Management'
    WHEN '元数据管理' THEN 'Metadata Management'
    WHEN '存储管理' THEN 'Storage Management'
    WHEN '作业管理' THEN 'Job Management'
    ELSE category_name
END,
 description = CASE function_name
    WHEN 'tables' THEN 'Table information'
    WHEN 'dbs' THEN 'Database information'
    WHEN 'tablet_schema' THEN 'Tablet schema details'
    WHEN 'partitions' THEN 'Partition information'
    WHEN 'backends' THEN 'Backend node information'
    WHEN 'frontends' THEN 'Frontend node information'
    WHEN 'brokers' THEN 'Broker node information'
    WHEN 'statistic' THEN 'Cluster statistics'
    WHEN 'transactions' THEN 'Transaction information'
    WHEN 'routine_loads' THEN 'Routine Load job information'
    WHEN 'stream_loads' THEN 'Stream Load job information'
    WHEN 'loads' THEN 'Load job information'
    WHEN 'load_error_hub' THEN 'Load error information'
    WHEN 'catalog' THEN 'Catalog information'
    WHEN 'resources' THEN 'Resource information'
    WHEN 'workgroups' THEN 'Workload group information'
    WHEN 'warehouses' THEN 'Warehouse information'
    WHEN 'tablets' THEN 'Tablet information'
    WHEN 'colocate_group' THEN 'Colocate Group information'
    WHEN 'compactions' THEN 'Compaction job information'
    WHEN 'routine_load_jobs' THEN 'Routine Load job information'
    WHEN 'jobs' THEN 'Job information'
    WHEN 'tasks' THEN 'Task information'
    WHEN 'stream_load_jobs' THEN 'Stream Load job information'
    WHEN 'bdbje' THEN 'BDBJE information'
    WHEN 'small_files' THEN 'Small file information'
    WHEN 'trash' THEN 'Recycle Bin information'
    WHEN 'repositories' THEN 'Repository information'
    ELSE description
END
WHERE is_system = TRUE;
