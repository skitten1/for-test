# 智能参数推荐系统设计文档

## 1. 概述

智能参数推荐系统是 StarRocks Admin Profile 分析器的核心功能之一，旨在根据查询特征、集群配置和当前参数设置，动态生成个性化的参数调优建议。

### 1.1 设计目标

- **智能化**：根据实际查询特征动态计算推荐值，而非静态硬编码
- **上下文感知**：考虑集群配置（BE 数量）、数据量、当前参数设置等因素
- **避免冗余**：当前值已满足推荐条件时，不生成重复建议
- **可解释性**：每个推荐都附带动态生成的理由说明

### 1.2 系统架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Profile 分析器                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────────┐                                               │
│  │  Handler 层       │                                               │
│  │  ┌──────────────┐ │                                               │
│  │  │ 获取集群变量  │ │  SHOW VARIABLES WHERE Variable_name IN (...) │
│  │  └──────────────┘ │                                               │
│  └────────┬─────────┘                                               │
│           │ ClusterVariables                                        │
│           ▼                                                          │
│  ┌──────────────────┐    ┌─────────────┐    ┌───────────────────┐   │
│  │   规则引擎        │───▶│  诊断规则   │───▶│ 智能参数推荐系统  │   │
│  └──────────────────┘    └─────────────┘    └───────────────────┘   │
│           │                     │                    │               │
│           ▼                     ▼                    ▼               │
│  ┌─────────────┐    ┌──────────────────┐    ┌───────────────────┐   │
│  │ ClusterInfo │    │   RuleContext    │    │ suggest_parameter │   │
│  │ - backend_num    │ - node           │    │ _smart()          │   │
│  │ - scan_bytes│    │ - session_vars   │    │                   │   │
│  └─────────────┘    │ - cluster_info   │    └───────────────────┘   │
│                     │ - cluster_vars ◀─┼── 优先使用集群实际值       │
│                     └──────────────────┘                            │
└─────────────────────────────────────────────────────────────────────┘
```

## 2. 核心数据结构

### 2.1 ClusterInfo - 集群信息

从 Profile 中提取的集群配置信息，用于智能推荐计算。

```rust
pub struct ClusterInfo {
    /// 参与查询的 BE 节点数量
    pub backend_num: u32,
    /// Fragment 实例总数（预留）
    pub instance_num: u32,
    /// 所有 Scan 算子扫描的总数据量（字节）
    pub total_scan_bytes: u64,
}
```

**提取逻辑**：
- `backend_num`: 从所有 Fragment 的 `backend_addresses` 中去重统计
- `total_scan_bytes`: 从执行树中所有 SCAN 节点的 `BytesRead` 指标累加

### 2.2 ClusterVariables - 集群变量

从集群实时获取的会话变量值，用于精确判断当前参数设置。

```rust
/// 从集群获取的实际会话变量值
pub type ClusterVariables = HashMap<String, String>;

/// 分析上下文
pub struct AnalysisContext {
    /// 集群实际变量值（优先级最高）
    pub cluster_variables: Option<ClusterVariables>,
}
```

**获取方式**：
```sql
SHOW VARIABLES WHERE Variable_name IN ('query_mem_limit', 'enable_spill', ...)
```

### 2.3 RuleContext - 规则上下文

规则评估时的上下文信息，包含智能推荐所需的所有数据。

```rust
pub struct RuleContext<'a> {
    /// 当前评估的执行树节点
    pub node: &'a ExecutionTreeNode,
    /// 非默认会话变量（从 Profile 解析）
    pub session_variables: &'a HashMap<String, SessionVariableInfo>,
    /// 集群信息（BE 数量、扫描数据量等）
    pub cluster_info: Option<ClusterInfo>,
    /// 集群实际变量值（优先级最高）
    pub cluster_variables: Option<&'a HashMap<String, String>>,
}
```

**变量值获取优先级**：
1. `cluster_variables` - 集群实际值（最准确）
2. `session_variables` - Profile 中的非默认值
3. `get_parameter_default()` - 已知默认值

### 2.3 ParameterSuggestion - 参数建议

```rust
pub struct ParameterSuggestion {
    pub name: String,           // 参数名
    pub param_type: ParameterType,  // Session 或 BE
    pub current: Option<String>,    // 当前值（如果已设置）
    pub recommended: String,        // 推荐值
    pub command: String,            // 设置命令
    pub description: String,        // 参数说明
    pub impact: String,             // 预期影响（含动态理由）
}
```

## 3. 智能推荐算法

### 3.1 推荐决策流程

```
                    ┌─────────────────┐
                    │   诊断规则触发   │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │   获取上下文     │
                    │ - 集群信息       │
                    │ - 当前参数值     │
                    │ - 查询特征       │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  计算推荐值      │
                    │ (基于规则)       │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │   跳过条件检查   │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
       ┌──────▼──────┐ ┌─────▼─────┐ ┌─────▼─────┐
       │当前值>=推荐值│ │数据量太小 │ │已启用/设置│
       └──────┬──────┘ └─────┬─────┘ └─────┬─────┘
              │              │              │
              └──────────────┼──────────────┘
                             │
                    ┌────────▼────────┐
                    │  满足跳过条件?   │
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
              │ Yes                         │ No
       ┌──────▼──────┐              ┌───────▼───────┐
       │   不推荐    │              │  生成建议      │
       │  (返回None) │              │ (含动态理由)   │
       └─────────────┘              └───────────────┘
```

### 3.2 参数推荐规则

#### 3.2.1 并行度相关

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `parallel_fragment_exec_instance_num` | `min(BE数量, 16)` | 当前值 >= 推荐值 或 数据量 < 100MB |
| `pipeline_dop` | `0` (auto) | 当前值 = 0 |
| `io_tasks_per_scan_operator` | 大数据量(>1GB)推荐`8` | 当前值 >= 推荐值 或 数据量 <= 1GB |

**示例**：
```
集群: 8 BE 节点
用户设置: parallel_fragment_exec_instance_num = 32
推荐值: min(8, 16) = 8
判断: 32 >= 8 → 不推荐
```

#### 3.2.2 内存相关

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `query_mem_limit` | `2 × 扫描数据量`, min 4GB, max 32GB | 当前值 >= 推荐值 |
| `enable_spill` | `true` | 已启用 |

**示例**：
```
扫描数据量: 5GB
推荐值: min(max(5GB × 2, 4GB), 32GB) = 10GB
动态理由: "根据数据量推荐 10GB 内存限制"
```

#### 3.2.3 查询优化

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `query_timeout` | `600` | 当前值 >= 600 |
| `enable_query_cache` | `true` | 已启用 |

#### 3.2.4 Runtime Filter

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `enable_global_runtime_filter` | `true` | 已启用 |
| `runtime_join_filter_push_down_limit` | `10000000` | 当前值 >= 10M |

#### 3.2.5 DataCache

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `enable_scan_datacache` | `true` | 已启用 |
| `enable_populate_datacache` | `true` | 已启用 |

#### 3.2.6 Profile 收集

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `pipeline_profile_level` | `1` | 当前值 <= 1 |

#### 3.2.7 BE 参数

| 参数 | 推荐逻辑 | 跳过条件 |
|------|---------|---------|
| `storage_page_cache_limit` | `30%` | IO 瓶颈时推荐 |

## 4. 实现细节

### 4.1 核心方法：`suggest_parameter_smart`

```rust
pub fn suggest_parameter_smart(&self, name: &str) -> Option<ParameterSuggestion> {
    let cluster_info = self.cluster_info.as_ref();
    
    // 1. 获取当前值（用户设置或默认值）
    let current_str = self.get_variable_value(name);
    let default_str = get_parameter_default(name).map(|s| s.to_string());
    let effective_value = current_str.as_ref().or(default_str.as_ref());
    
    // 2. 根据参数类型计算推荐值和跳过条件
    let (recommended, reason, param_type) = match name {
        "parallel_fragment_exec_instance_num" => {
            let be_count = cluster_info.map(|c| c.backend_num).unwrap_or(1).max(1);
            let recommended = be_count.min(16) as i64;
            let current = current_i64.unwrap_or(1);
            
            // 跳过条件
            if current >= recommended { return None; }
            if cluster_info.map(|c| c.total_scan_bytes < 100_000_000).unwrap_or(true) {
                return None;
            }
            
            (recommended.to_string(), 
             format!("根据集群 {} 个 BE 节点推荐", be_count), 
             ParameterType::Session)
        }
        // ... 其他参数
    };
    
    // 3. 生成建议
    Some(ParameterSuggestion {
        name: name.to_string(),
        param_type,
        current: self.get_variable_value(name),
        recommended,
        command: format!("SET {} = {};", name, recommended),
        description: metadata.description,
        impact: format!("{} ({})", metadata.impact, reason),
    })
}
```

### 4.2 查询级别推荐：`suggest_query_parameter`

用于查询级别规则（如 Q001-Q009），没有节点上下文但有完整 Profile。

```rust
fn suggest_query_parameter(profile: &Profile, name: &str) -> Option<ParameterSuggestion> {
    let cluster_info = profile.get_cluster_info();
    
    // 获取当前值
    let current_str = profile.summary.non_default_variables.get(name)
        .map(|v| v.actual_value_str());
    
    // 计算推荐值（与 suggest_parameter_smart 类似）
    // ...
}
```

## 5. 使用示例

### 5.1 节点级别规则

```rust
// 在 exchange.rs 中
fn evaluate(&self, context: &RuleContext) -> Option<Diagnostic> {
    // ... 诊断逻辑 ...
    
    Some(Diagnostic {
        // ...
        parameter_suggestions: {
            let mut suggestions = Vec::new();
            if let Some(s) = context.suggest_parameter_smart("parallel_fragment_exec_instance_num") {
                suggestions.push(s);
            }
            if let Some(s) = context.suggest_parameter_smart("pipeline_dop") {
                suggestions.push(s);
            }
            suggestions
        },
    })
}
```

### 5.2 查询级别规则

```rust
// 在 query.rs 中
fn evaluate(&self, profile: &Profile) -> Option<QueryDiagnostic> {
    // ... 诊断逻辑 ...
    
    Some(QueryDiagnostic {
        // ...
        parameter_suggestions: {
            let mut suggestions = Vec::new();
            if let Some(s) = suggest_query_parameter(profile, "query_timeout") {
                suggestions.push(s);
            }
            if let Some(s) = suggest_query_parameter(profile, "query_mem_limit") {
                suggestions.push(s);
            }
            suggestions
        },
    })
}
```

## 6. 前端展示

### 6.1 API 响应格式

```json
{
  "parameter_suggestions": [
    {
      "name": "parallel_fragment_exec_instance_num",
      "param_type": "Session",
      "current": "1",
      "recommended": "8",
      "command": "SET parallel_fragment_exec_instance_num = 8;",
      "description": "每个 Fragment 的并行执行实例数",
      "impact": "增大可提升并行度，但会占用更多资源 (根据集群 8 个 BE 节点推荐)"
    }
  ]
}
```

### 6.2 UI 展示效果

```
┌─────────────────────────────────────────────────────────────┐
│ ⚙️ parallel_fragment_exec_instance_num          [Session]   │
│   每个 Fragment 的并行执行实例数                             │
│   📈 增大可提升并行度 (根据集群 8 个 BE 节点推荐)            │
│   当前值: 1 → 推荐值: 8                                     │
│   ┌─────────────────────────────────────────────────────┐   │
│   │ SET parallel_fragment_exec_instance_num = 8; [复制] │   │
│   └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## 7. 扩展指南

### 7.1 添加新参数

1. 在 `get_parameter_default()` 中添加默认值
2. 在 `get_parameter_metadata()` 中添加描述和影响说明
3. 在 `suggest_parameter_smart()` 中添加推荐逻辑

```rust
// 1. 默认值
"new_param" => Some("default_value"),

// 2. 元数据
"new_param" => ParameterMetadata {
    description: "参数说明".to_string(),
    impact: "预期影响".to_string(),
},

// 3. 推荐逻辑
"new_param" => {
    let current = current_i64.unwrap_or(default);
    if current >= recommended { return None; }
    (recommended.to_string(), "推荐理由".to_string(), ParameterType::Session)
}
```

### 7.2 添加新的跳过条件

在参数的 match 分支中添加额外的条件检查：

```rust
"param_name" => {
    // 新的跳过条件
    if some_condition {
        return None;
    }
    // ...
}
```

## 8. 测试

### 8.1 单元测试

```rust
#[test]
fn test_smart_recommendation_skips_when_current_exceeds() {
    let context = create_test_context_with_variable(
        "parallel_fragment_exec_instance_num", 
        "32"
    );
    let suggestion = context.suggest_parameter_smart("parallel_fragment_exec_instance_num");
    assert!(suggestion.is_none(), "Should skip when current >= recommended");
}
```

### 8.2 集成测试

使用真实 Profile 文件测试完整的分析流程，验证参数推荐的正确性。

## 9. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0 | 2025-12-05 | 初始版本，支持 13 个参数的智能推荐 |
