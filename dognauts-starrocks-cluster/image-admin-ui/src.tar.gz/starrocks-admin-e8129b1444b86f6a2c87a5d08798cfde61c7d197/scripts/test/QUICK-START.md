# 🚀 多租户测试快速开始

## 一键运行

```bash
cd /home/oppo/Documents/starrocks-admin/scripts/test
./test-multi-tenant-all.sh
```

## 分步运行

```bash
# Step 1: 超级管理员测试
./test-multi-tenant-super-admin.sh

# Step 2: 组织管理员测试
./test-multi-tenant-org-admin.sh

# Step 3: 普通用户测试
./test-multi-tenant-regular-user.sh
```

## 测试账号

| 角色 | 用户名 | 密码 | 用途 |
|-----|--------|------|------|
| 超级管理员 | `admin` | `admin` | 创建组织和全局管理 |
| Alpha 组织管理员 | `alpha_admin` | `Alpha@123` | 管理 Alpha 组织 |
| Beta 组织管理员 | `beta_admin` | `Beta@123` | 管理 Beta 组织 |
| Alpha 普通用户 | `alpha_user1` | `User@123` | 有限权限访问 |

## 测试架构

```
┌─────────────────────────────────────────────────────────┐
│                    Super Admin (admin)                   │
│  • 创建 2 个组织 (Alpha, Beta)                            │
│  • 创建组织管理员 (alpha_admin, beta_admin)               │
│  • 为每个组织创建集群                                      │
│  • 创建系统级角色                                          │
└─────────────────────────────────────────────────────────┘
                            ↓
        ┌───────────────────┴───────────────────┐
        ↓                                       ↓
┌───────────────────┐                 ┌───────────────────┐
│ Organization Alpha │                 │ Organization Beta │
│  • alpha_admin    │                 │  • beta_admin    │
│  • alpha_user1    │                 │                  │
│  • alpha_cluster  │                 │  • beta_cluster  │
│  • alpha_developer│                 │                  │
└───────────────────┘                 └───────────────────┘
        ↓
┌───────────────────┐
│ alpha_user1       │
│  • 查看集群        │
│  • 执行查询        │
│  • 受权限限制      │
└───────────────────┘
```

## 验证点

### ✅ 超级管理员
- [x] 创建组织
- [x] 跨组织查看资源
- [x] 为任意组织创建集群
- [x] 创建系统级角色

### ✅ 组织管理员
- [x] 只能看到自己的组织
- [x] 创建组织内用户
- [x] 创建组织内集群
- [x] 无法创建系统角色
- [x] 无法访问其他组织

### ✅ 普通用户
- [x] 只能访问授权集群
- [x] 无法创建集群/用户/角色
- [x] 受组织作用域限制

## 预期输出

成功时：
```
================================================
✓ ALL TESTS PASSED
================================================
The multi-tenant system is working correctly!
```

## 前提条件

1. ✅ 后端运行在 http://localhost:8081
2. ✅ 使用 admin/admin 可以登录
3. ✅ 已安装 curl 和 python3

## 故障排查

**问题：后端未运行**
```bash
# 检查进程
ps aux | grep starrocks-admin

# 检查端口
lsof -i :8081

# 启动后端
cd /home/oppo/Documents/starrocks-admin
./scripts/dev/start-backend.sh
```

**问题：登录失败**
- 确保按顺序运行脚本
- 检查用户是否已创建

**问题：权限被拒绝**
```bash
# 赋予执行权限
chmod +x test-multi-tenant-*.sh
```

## 清理数据

如需重新测试，可以重启后端或清理数据库：

```bash
# 删除数据库文件
rm /home/oppo/Documents/starrocks-admin/backend/starrocks_admin.db

# 重启后端
./scripts/dev/restart-backend.sh
```

## 下一步

测试通过后，可以：
1. 访问前端界面 http://localhost:4200
2. 使用上述账号登录体验
3. 查看详细文档 `README-MULTI-TENANT-TESTS.md`
