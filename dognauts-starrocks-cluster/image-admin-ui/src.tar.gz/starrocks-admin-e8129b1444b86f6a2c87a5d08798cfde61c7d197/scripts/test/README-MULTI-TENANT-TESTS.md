# Multi-Tenant API Testing Scripts

## 📋 概述

这些脚本用于测试 StarRocks Admin 的多租户功能，覆盖三种用户角色的完整操作流程。

## 🎯 测试角色

### 1. 超级管理员 (Super Admin)
- **用户名**: `admin`
- **密码**: `admin`
- **权限**: 完全控制，可以创建组织、管理所有资源、跨组织操作

### 2. 组织管理员 (Organization Admin)
- **用户名**: `alpha_admin` / `beta_admin`
- **密码**: `Alpha@123` / `Beta@123`
- **权限**: 只能管理所属组织的资源，无法访问其他组织

### 3. 普通用户 (Regular User)
- **用户名**: `alpha_user1`
- **密码**: `User@123`
- **权限**: 最小权限，只能访问被授权的资源

## 📁 测试脚本

```
scripts/test/
├── test-multi-tenant-super-admin.sh    # 超级管理员测试
├── test-multi-tenant-org-admin.sh      # 组织管理员测试
├── test-multi-tenant-regular-user.sh   # 普通用户测试
└── test-multi-tenant-all.sh            # 一键运行所有测试
```

## 🚀 快速开始

### 前提条件

1. 后端服务运行在 `http://localhost:8081`
2. 使用默认超级管理员账号 (`admin/admin`)
3. 已安装 `curl` 和 `python3`

### 方式一：一键运行所有测试

```bash
cd /home/oppo/Documents/starrocks-admin/scripts/test
./test-multi-tenant-all.sh
```

### 方式二：单独运行测试

```bash
# 1. 运行超级管理员测试（创建基础设施）
./test-multi-tenant-super-admin.sh

# 2. 运行组织管理员测试（验证组织隔离）
./test-multi-tenant-org-admin.sh

# 3. 运行普通用户测试（验证权限限制）
./test-multi-tenant-regular-user.sh
```

## 📊 测试覆盖范围

### 超级管理员测试 (test-multi-tenant-super-admin.sh)

✅ **步骤：**
1. 使用 admin/admin 登录
2. 验证超级管理员身份
3. 创建组织 Alpha (含管理员 alpha_admin)
4. 创建组织 Beta (含管理员 beta_admin)
5. 列出所有组织
6. 为组织 Alpha 创建集群
7. 为组织 Beta 创建集群
8. 列出所有集群（跨组织视图）
9. 列出所有用户
10. 创建系统级角色
11. 列出所有角色

✅ **验证点：**
- 超级管理员可以创建组织
- 超级管理员可以查看所有组织的资源
- 超级管理员可以为任意组织创建集群
- 超级管理员可以创建系统级角色

### 组织管理员测试 (test-multi-tenant-org-admin.sh)

✅ **步骤：**
1. 使用 alpha_admin/Alpha@123 登录
2. 验证用户身份和组织关联
3. 获取当前组织详情
4. 列出组织（应只看到自己的组织）
5. 在组织内创建用户 (alpha_user1)
6. 列出组织内用户
7. 创建组织级角色 (alpha_developer)
8. 列出组织内角色
9. 列出组织内集群
10. 为组织创建额外集群
11. 尝试创建系统角色（应失败）
12. 尝试访问组织 Beta（应失败）

✅ **验证点：**
- 组织管理员只能看到自己的组织
- 组织管理员创建的用户自动关联到当前组织
- 组织管理员只能创建组织级角色
- 组织管理员无法创建系统角色
- 组织管理员无法访问其他组织的资源

### 普通用户测试 (test-multi-tenant-regular-user.sh)

✅ **步骤：**
1. 使用 alpha_user1/User@123 登录
2. 验证用户身份
3. 列出可见集群
4. 获取集群详情
5. 尝试创建集群（应失败）
6. 尝试创建用户（应失败）
7. 尝试创建角色（应失败）
8. 尝试列出组织（应被限制）
9. 执行查询（如果有权限）
10. 尝试列出用户（应被限制）
11. 尝试列出角色（应被限制）

✅ **验证点：**
- 普通用户无法执行管理操作
- 普通用户只能访问被授权的集群
- 普通用户无法创建资源
- 普通用户作用域限定在组织内

## 🔍 测试输出说明

### 颜色标识
- 🟢 **绿色**: 测试通过
- 🟡 **黄色**: 警告或提示信息
- 🔵 **蓝色**: 步骤说明
- 🔴 **红色**: 测试失败

### 输出示例

```bash
[Step 1] Login as Super Admin (admin/admin)...
✓ Login successful
Token: eyJhbGciOiJIUzI1NiI...

[Step 3] Create Organization Alpha...
✓ Organization Alpha created (ID: 2)
{
  "id": 2,
  "code": "ORG_ALPHA",
  "name": "Alpha Corporation",
  ...
}
```

## 🎭 测试场景设计

### 场景 1: 多组织资源隔离
- 创建两个组织：Alpha 和 Beta
- 每个组织都有自己的管理员、用户、角色和集群
- 验证组织间资源完全隔离

### 场景 2: 角色权限验证
- 超级管理员：全局管理权限
- 组织管理员：组织内管理权限
- 普通用户：只读或有限操作权限

### 场景 3: 边界测试
- 组织管理员尝试访问其他组织 → 403 Forbidden
- 普通用户尝试创建资源 → 403 Forbidden
- 普通用户尝试查看未授权集群 → 403 Forbidden

## 📝 测试数据

### 组织
- **Alpha Corporation** (ORG_ALPHA)
- **Beta Industries** (ORG_BETA)

### 用户
| 用户名 | 密码 | 角色 | 组织 |
|--------|------|------|------|
| admin | admin | Super Admin | - |
| alpha_admin | Alpha@123 | Org Admin | Alpha |
| beta_admin | Beta@123 | Org Admin | Beta |
| alpha_user1 | User@123 | Regular User | Alpha |

### 集群
- **alpha_cluster** - Alpha 组织主集群
- **alpha_cluster_dev** - Alpha 组织开发集群
- **beta_cluster** - Beta 组织主集群

### 角色
- **system_auditor** - 系统级审计角色
- **alpha_developer** - Alpha 组织开发者角色

## ⚠️ 注意事项

1. **执行顺序**: 必须按照 super-admin → org-admin → regular-user 的顺序执行
2. **依赖关系**: 后续测试依赖前面测试创建的数据
3. **清理数据**: 测试脚本不会自动清理数据，如需重新测试，请手动清理数据库
4. **端口配置**: 默认后端端口为 8081，如有修改请编辑脚本中的 `BASE_URL`

## 🔧 故障排查

### 问题：登录失败
```bash
✗ Login failed
Note: Make sure you ran test-multi-tenant-super-admin.sh first
```
**解决**: 确保按顺序运行脚本，或检查用户是否已创建

### 问题：403 Forbidden
```bash
✗ Cannot access cluster details (HTTP 403)
```
**解决**: 这可能是预期行为，验证权限配置是否正确

### 问题：后端未响应
```bash
curl: (7) Failed to connect to localhost port 8081
```
**解决**: 
1. 检查后端是否在运行：`ps aux | grep starrocks-admin`
2. 检查端口：`lsof -i :8081`
3. 启动后端：`cd backend && cargo run`

## 📈 预期结果

所有测试通过后，应该看到：

```
================================================
✓ ALL TESTS PASSED
================================================

Multi-Tenant Feature Verification:
  ✓ Organizations created and isolated
  ✓ Super admin can manage all resources
  ✓ Org admins are scoped to their organization
  ✓ Regular users have limited permissions
  ✓ Cross-org access is blocked
  ✓ Role-based access control working

The multi-tenant system is working correctly!
```

## 🔗 相关文档

- [多租户设计文档](../../docs/multi-tenant-design.md)
- [API 文档](../../docs/api.md)
- [权限模型](../../docs/permissions.md)

## 📞 联系方式

如有问题，请参考项目 README 或提交 Issue。
